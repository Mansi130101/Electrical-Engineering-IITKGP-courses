function [y] = mfun1(x)
    y = x.*exp(-x); 
end