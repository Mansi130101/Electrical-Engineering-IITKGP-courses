function [y] = mfun2(x)
y=exp(-x)-x.*exp(-x);
end