function out = f1(t,y)
out=2.*ones(size(y));
end