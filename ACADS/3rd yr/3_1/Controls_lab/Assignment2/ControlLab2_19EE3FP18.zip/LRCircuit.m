function dxdt=LRCircuit(t,I)
dxdt=1-0.5.*I;
end