function out = f2(t,y)
out=3*t*t.*ones(size(y));
end